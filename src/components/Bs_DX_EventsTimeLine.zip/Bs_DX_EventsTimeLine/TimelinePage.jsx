import TimeBlock from "./Timeblock.jsx";
import { useContext } from "react";
import DataContext from "./DataContext.js";
import { BadgePoundSterling, BriefcaseBusiness } from 'lucide-react';


const transformTimelineData = (timelineData, sortBy)=>{
  let processedTimelineData;
  if (sortBy === 'Newest First'){
    processedTimelineData = [...timelineData].sort((a, b) =>
      new Date(b.EventDateTime) - new Date(a.EventDateTime)) // sort newest first
  }else{
    processedTimelineData = [...timelineData].sort((a, b) =>
      new Date(a.EventDateTime) - new Date(b.EventDateTime)) // oldest  first
  }

  return processedTimelineData.map((item, index) => {
    const rawDateTime = item.EventDateTime;
    let date = "No Date Found";
    let time = "No Time Found";

    if (rawDateTime) {
      const dateObj = new Date(rawDateTime);
      date = dateObj.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
      });
      time = dateObj.toLocaleTimeString('en-GB', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
    }

    const icon = item.Category === "Financial" ? <BadgePoundSterling/> : <BriefcaseBusiness/>;

    return {
      id: `event-${index}`,
      date,
      time,
      description: item.Description || "No Description",
      icon,
      caseType: item.caseType,
      insKey: item.insKey,
      category: item.Category || "Uncategorised"
    };
  });
}


export default function TimeLinePage() {
const { timelineData = [], sortBy } = useContext(DataContext) || {};

  const timelineStyle = {
    display: 'flex',
    gap: '5px',
    width: '100%',
    overflowX: 'auto',
    overflowY: 'hidden',
    padding: '10px',
    fontSize: '14px',
    scrollBehavior: 'smooth',
    WebkitOverflowScrolling: 'touch'
  };

  const blockStyle = {
    scrollSnapAlign: 'start',
    flexShrink: 0
  };

  // Process timeline data
  const processedTimelineData = transformTimelineData(timelineData, sortBy)

  return (
    <div>
      <div style={timelineStyle}>
        {processedTimelineData.map((item) => (
          <div key={item.id} style={blockStyle}>
            <TimeBlock
              date={item.date}
              category={item.category}
              time={item.time}
              icon={item.icon}
              description={item.description}
              caseType={item.caseType}
              insKey={item.insKey}
            />
          </div>
        ))}
      </div>

      {processedTimelineData.length === 0 && (
        <div style={{padding: '20px', textAlign: 'center', color: '#666'}}>
          No events found.
        </div>
      )}
    </div>
  );
}
