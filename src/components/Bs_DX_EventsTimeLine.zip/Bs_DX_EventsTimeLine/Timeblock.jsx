import { Fragment, Children, type ReactElement } from 'react';
import { Grid, FieldGroup, withConfiguration, type GridContainerProps } from '@pega/cosmos-react-core';
import type { PConnFieldProps } from './PConnProps';
import './create-nonce';

import DetailsRender from './DetailsRender';
import HighlightRender from './HighlightRender';

import StyledBsDxFieldGroupAsRowWrapper, { StyledDetailsGridContainer, StyledHighlightedFieldsHrLine } from './styles';

// includes in bundle
import { getAllFields } from './utils';

// interface for props
interface BsDxFieldGroupAsRowProps extends PConnFieldProps {
  // If any, enter additional props that only exist on TextInput here
  showLabel: boolean;
  showHighlightedData: boolean;
  children: any;
}

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
function BsDxFieldGroupAsRow(props: BsDxFieldGroupAsRowProps) {

  const { getPConnect, label, showLabel = true, showHighlightedData = false  } = props;
  const propsToUse = { label, showLabel, ...getPConnect().getInheritedProps() };

  // storybook doesn't get children of 1 as an array of 1
  let { children } = props;
  if (!Array.isArray(children)) {
    children = Children.toArray(children);
  }

  // update children with readonly
  Children.toArray(children).forEach(child => {
    // @ts-ignore
    child.props.getPConnect().setInheritedProp('readOnly', true);
    // @ts-ignore
    child.props.getPConnect().setInheritedProp('displayMode', 'DISPLAY_ONLY');
  });

  const numRegions = getAllFields(getPConnect)?.length;
  const gridRepeat = "repeat(".concat(numRegions).concat(", 1fr)");

  const gridContainer: GridContainerProps = { colGap: 6 };
  gridContainer.cols = gridRepeat;
  gridContainer.alignItems = 'start';

  // Set up highlighted data to pass in return if is set to show, need raw metadata to pass to createComponent
  let highlightedDataArr = [];
  if (showHighlightedData) {
    // @ts-ignore
    const { highlightedData = [] } = getPConnect().getRawMetadata().config;
    // @ts-ignore
    highlightedDataArr = highlightedData.map((field) => {
      return <HighlightRender field={field} getPConnect={props.getPConnect} />;
    });
  }

  return (


<>
    <style>
        {`
            .FlexRowEnd {
                display: flex
            ;
                flex-direction: row;
                align-items: baseline;
                justify-content: flex-end;
                gap: 10px;
                width: 100%;
            }
            .DetailsContainer{
                display: flex
                ;
                justify-content: flex-end;
            }
        `}
      </style>

  <div className='DetailsContainer'>
    <StyledBsDxFieldGroupAsRowWrapper>
        <FieldGroup name={propsToUse.showLabel ? propsToUse.label : ''}>
          {showHighlightedData && highlightedDataArr.length > 0 && (
              <>
                <div className="FlexRowEnd">
                  {highlightedDataArr.map((child: ReactElement, i: number) => (
                    <Fragment key={`hf-${i + 1}`}>{child}</Fragment>
                  ))}
                </div>
                <StyledHighlightedFieldsHrLine />
              </>
          )}

          {children.map((child: ReactElement, i: number) => (

          <div className="FlexRowEnd">

              <DetailsRender key={`hf-${i + 1}`} child={child} />
            </div>
          ))}

        </FieldGroup>
    </StyledBsDxFieldGroupAsRowWrapper>

</div>
</>
  );

}


export default withConfiguration(BsDxFieldGroupAsRow);
